from django.apps import AppConfig


class GetAwayFromIcelandConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'get_away_from_iceland'
