from django.apps import AppConfig


class YoyocoinConfig(AppConfig):
    name = 'yoyocoin'
