from django.apps import AppConfig


class Jam42BabelConfig(AppConfig):
    name = 'jam42_babel'
