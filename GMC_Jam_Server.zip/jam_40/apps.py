from django.apps import AppConfig


class Jam40Config(AppConfig):
    name = 'jam_40'
